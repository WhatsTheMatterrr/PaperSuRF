import main as papersurf

papersurf.main()
